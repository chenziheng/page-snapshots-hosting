# 网页快照托管服务 (Page Snapshots Hosting)

这是一个专门用于托管网页快照的静态网站项目，配合 [Batch Page Saver Extension](https://github.com/chenziheng/batch-page-saver-extension-) Chrome插件使用。

## 🎯 功能特性

- **自动托管**：通过Chrome插件API自动上传网页快照
- **即时访问**：上传后立即生成公开可访问的链接
- **AI友好**：生成的链接可直接分享给ChatGPT等AI进行分析
- **响应式设计**：支持各种设备访问
- **全球CDN**：基于Vercel的全球加速网络

## 📁 目录结构

```
page-snapshots-hosting/
├── index.html          # 主页
├── vercel.json         # Vercel配置文件
├── snapshots/          # 单页快照目录
│   └── YYYY-MM-DD/     # 按日期组织
└── collections/        # 批量快照目录
    └── YYYY-MM-DD/     # 按日期组织
```

## 🚀 部署说明

1. 将此项目推送到GitHub
2. 在Vercel中导入此GitHub仓库
3. 自动部署完成

## 🔗 API端点

- `GET /` - 主页
- `GET /snapshots/YYYY-MM-DD/filename.html` - 访问单页快照
- `GET /collections/YYYY-MM-DD/batch-id/index.html` - 访问批量快照目录页

## 🛠️ 配置

通过 `vercel.json` 配置：
- 静态文件托管
- CORS跨域支持
- 路由规则

## 📝 使用方法

1. 安装并配置 Batch Page Saver Extension
2. 在插件设置中连接此Vercel项目
3. 当AI无法访问链接时，插件会自动：
   - 抓取目标网页
   - 上传到此托管服务
   - 生成公开链接
   - 自动插入到AI对话框

## 🔒 隐私说明

- 所有上传的快照都是公开可访问的
- 建议不要上传包含敏感信息的页面
- 快照链接采用随机文件名，不易被猜测

## 📄 许可证

MIT License

---

**配合使用**：[Batch Page Saver Extension](https://github.com/chenziheng/batch-page-saver-extension-)
